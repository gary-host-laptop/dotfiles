from calibre.ebooks.metadata.sources.base import Source
from calibre.ebooks.metadata.book.base import Metadata

import urllib.request
import json
import unicodedata
import datetime
import re
from bs4 import BeautifulSoup


class OpenLibraryPlus(Source):

    name = 'OpenLibraryPlus'
    description = 'OpenLibrary metadata (HTML + JSON) with cover, rating, tags and series'
    author = 'Dunhill'
    version = (1, 3, 0)  # Incrementado para reflejar los cambios
    minimum_calibre_version = (6, 0, 0)
    supported_platforms = ['windows', 'osx', 'linux']
    capabilities = frozenset(['identify', 'cover'])

    # --------------------------------------------------
    # Utils
    # --------------------------------------------------

    def normalize(self, text):
        return ''.join(
            c for c in unicodedata.normalize('NFD', text or '')
            if unicodedata.category(c) != 'Mn'
        ).lower()

    def fetch_url(self, url, timeout=30):
        req = urllib.request.Request(
            url, headers={'User-Agent': 'Mozilla/5.0'}
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode('utf-8')

    def parse_publish_date(self, raw):
        if not raw:
            return None
        m = re.search(r'(\d{4})', raw)
        if m:
            # CORRECCIÓN: Devolvemos datetime.datetime en lugar de date
            # para evitar errores de mezcla de tipos en Calibre.
            return datetime.datetime(int(m.group(1)), 1, 1, 0, 0, 0)
        return None

    # --------------------------------------------------
    # IDENTIFY
    # --------------------------------------------------

    def identify(self, log, result_queue, abort,
                 title=None, authors=None, identifiers={},
                 timeout=30, **kwargs):

        ol_id = identifiers.get('openlibrary')
        
        # Limpiar el ID si viene con prefijo (ej: openlibrary:OL123W)
        if ol_id and ':' in ol_id:
            ol_id = ol_id.split(':')[-1]

        # --- Buscar por ISBN ---
        if not ol_id and 'isbn' in identifiers:
            try:
                data = json.loads(
                    self.fetch_url(
                        f'https://openlibrary.org/isbn/{identifiers["isbn"]}.json',
                        timeout
                    )
                )
                if data.get('key', '').startswith('/books/'):
                    ol_id = data['key'].split('/')[-1]
            except Exception as e:
                log.error(f'ISBN lookup error: {e}')

        # --- Buscar por título / autor ---
        if not ol_id and title and authors:
            q = f'{title} {authors[0]}'.replace(' ', '+')
            try:
                data = json.loads(
                    self.fetch_url(
                        f'https://openlibrary.org/search.json?q={q}',
                        timeout
                    )
                )
                if data.get('docs'):
                    ol_id = data['docs'][0]['key'].split('/')[-1]
            except Exception as e:
                log.error(f'Search error: {e}')

        if not ol_id:
            return

        try:
            # --------------------------------------------------
            # HTML
            # --------------------------------------------------
            html = self.fetch_url(
                f'https://openlibrary.org/books/{ol_id}', timeout
            )
            soup = BeautifulSoup(html, 'html.parser')

            og_title = soup.find('meta', property='og:title')
            og_desc = soup.find('meta', property='og:description')

            title_val = ''
            authors_val = []

            if og_title and og_title.get('content'):
                raw = og_title['content']
                if ' by ' in raw:
                    title_val, auth = raw.split(' by ', 1)
                    authors_val = [auth.split('|')[0].strip()]
                else:
                    title_val = raw.strip()

            if not authors_val and og_desc and og_desc.get('content'):
                if ' by ' in og_desc['content']:
                    authors_val = [
                        og_desc['content'].split(' by ')[1].split(',')[0].strip()
                    ]

            mi = Metadata(title_val, authors_val)
            mi.identifiers['openlibrary'] = ol_id

            # --- Sinopsis ---
            desc_block = soup.find('div', class_='book-description')
            if desc_block:
                content = desc_block.find('div', class_='read-more__content')
                if content:
                    mi.comments = content.get_text(' ', strip=True)
            elif og_desc and og_desc.get('content'):
                mi.comments = og_desc['content']

            # --- Fecha ---
            date_span = soup.find('span', itemprop='datePublished')
            if date_span:
                pubdate = self.parse_publish_date(date_span.get_text())
                if pubdate:
                    mi.pubdate = pubdate

            # --- Editorial ---
            publisher = soup.find('a', itemprop='publisher')
            if publisher:
                mi.publisher = publisher.get_text(strip=True)

            # --------------------------------------------------
            # 🌍 IDIOMA (HTML)
            # --------------------------------------------------
            lang_span = soup.find('span', itemprop='inLanguage')
            if lang_span:
                lang_a = lang_span.find('a')
                if lang_a:
                    href = lang_a.get('href', '')
                    m = re.search(r'/languages/([a-z]{3})', href)
                    if m:
                        mi.language = m.group(1)

            # --------------------------------------------------
            # ⭐ RATING (HTML)
            # --------------------------------------------------
            rating_block = soup.find(
                'ul',
                {'class': re.compile(r'readers-stats')},
                itemprop='aggregateRating'
            )
            if rating_block:
                rating_meta = rating_block.find('meta', itemprop='ratingValue')
                if rating_meta and rating_meta.get('content'):
                    try:
                        rating_val = float(rating_meta['content'])
                        rating_int = int(round(rating_val))
                        if 0 <= rating_int <= 5:
                            mi.rating = rating_int
                    except Exception:
                        pass

            # --------------------------------------------------
            # 🏷️ TAGS / TEMAS (HTML)
            # --------------------------------------------------
            tags = []
            tags_block = soup.find('div', class_='section link-box')
            if tags_block:
                for a in tags_block.find_all('a'):
                    tag = a.get_text(strip=True)
                    if tag:
                        # CORRECCIÓN: Reemplazamos comas para que Calibre
                        # no divida una sola etiqueta en varias.
                        tags.append(tag.replace(',', '-'))

            if tags:
                mi.tags = sorted(set(tags))

            # --------------------------------------------------
            # 📚 SERIE (HTML)
            # --------------------------------------------------
            dt_serie = soup.find('dt', string=re.compile(r'^Serie$', re.I))
            if dt_serie:
                dd_serie = dt_serie.find_next_sibling('dd', class_='object')
                if dd_serie:
                    serie_text = dd_serie.get_text(strip=True)
                    serie_text = serie_text.replace('—', '--').replace('–', '--')

                    m = re.match(r'(.+?)\s*--\s*(\d+(?:[.,]\d+)?)', serie_text)
                    if m:
                        mi.series = m.group(1).strip()
                        mi.series_index = float(m.group(2).replace(',', '.'))
                    else:
                        mi.series = serie_text
                        mi.series_index = 1.0

            result_queue.put(mi)

        except Exception as e:
            log.error(f'Identify error: {e}')

    # --------------------------------------------------
    # COVER
    # --------------------------------------------------

    def download_cover(self, log, result_queue, abort,
                        title=None, authors=None, identifiers={},
                        timeout=30, **kwargs):

        ol_id = identifiers.get('openlibrary')
        if not ol_id:
            return

        ol_id = ol_id.replace('openlibrary:', '')

        try:
            cover_url = None

            # HTML og:image
            html = self.fetch_url(
                f'https://openlibrary.org/books/{ol_id}', timeout
            )
            soup = BeautifulSoup(html, 'html.parser')
            og_image = soup.find('meta', property='og:image')
            if og_image and og_image.get('content'):
                cover_url = og_image['content']

            # JSON fallback
            if not cover_url:
                api = json.loads(
                    self.fetch_url(
                        f'https://openlibrary.org/books/{ol_id}.json',
                        timeout
                    )
                )
                if api.get('covers'):
                    cover_url = (
                        f'https://covers.openlibrary.org/b/id/'
                        f'{api["covers"][0]}-L.jpg'
                    )

            if cover_url:
                req = urllib.request.Request(
                    cover_url, headers={'User-Agent': 'Mozilla/5.0'}
                )
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    result_queue.put((self, r.read()))

        except Exception as e:
            log.error(f'Cover download error: {e}')
